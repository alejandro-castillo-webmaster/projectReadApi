export const environment = {
  production: true,
  apiUrl: "https://pokeapi.co/api/v2/",
};
