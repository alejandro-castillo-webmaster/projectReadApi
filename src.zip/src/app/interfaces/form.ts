export interface pokemons {
    name: string;
    weight: number;
    type: string;
}